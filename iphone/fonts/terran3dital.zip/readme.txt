Terran Truetype Font for Windows

2014 Iconian Fonts - Daniel Zadorozny

http://www.iconian.com/

This font comes with the following 21 versions: Regular, Italic, Condensed, Condensed Italic, Expanded, Expanded Italic, Drop-Case, Drop-Case Italic, Outline, Outline Italic, 3D, 3D Italic, Gradient, Gradient Italic, Chrome, Chrome Italic, Half-Tone, Half-Tone Italic, Academy, Academy Italic and Leftalic.  

This font may be freely distributed and is free for all non-commercial uses.  Use of the fonts are at your own risk. 

For commercial use of the font please visit http://iconian.com/commercial.html for additional information.

This font is e-mailware; that is, if you like it, please e-mail the author at:

iconian@aol.com
